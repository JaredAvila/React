import React, { Component } from "react";

class footer extends Component {
  filterItems(status) {
    this.props.filterItems(status);
  }
  footerText() {
    return this.props.getFooterText();
  }
  render() {
    return (
      <div id="footer">
        <div id="links">
          <p className="links" onClick={this.filterItems.bind(this, "all")}>
            All
          </p>
          <p className="links" onClick={this.filterItems.bind(this, "active")}>
            Active
          </p>
          <p
            className="links"
            onClick={this.filterItems.bind(this, "completed")}
          >
            Completed
          </p>
        </div>
        <p>
          Items left: {this.props.count}
          <br /> {this.footerText()}
        </p>
      </div>
    );
  }
}

export default footer;
