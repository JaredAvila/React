import React, { Component } from "react";

class editTodo extends Component {
  submitEdit(id, e) {
    // console.log(id);
    this.refs.text.value === ""
      ? alert("Cannot be blank")
      : this.props.editItem(id, this.refs.text.value);
    e.preventDefault();
  }
  render() {
    return (
      <form onSubmit={this.submitEdit.bind(this, this.props.item.id)}>
        <input
          className="editItem"
          defaultValue={this.props.item.text}
          ref="text"
        />
        <button className="bttn bttn-blue">Save</button>
      </form>
    );
  }
}

export default editTodo;
