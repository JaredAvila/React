import React, { Component } from "react";
import EditTodo from "./editTodo";

class Todo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      classes: ""
    };
  }
  checkItem(id) {
    this.props.onCheck(id);
  }
  deleteItem(id) {
    this.props.onDelete(id);
  }
  editItem(id, text) {
    this.props.editItem(id, text);
    this.props.updateEdit(id);
  }

  showEdit(id) {
    this.props.updateEdit(id);
  }
  render() {
    return (
      <li
        id={this.props.item.id}
        key={this.props.item.id}
        className="listItems"
        onDoubleClick={this.showEdit.bind(this, this.props.item.id)}
      >
        <span className={this.props.item.edit}>
          <EditTodo
            item={this.props.item}
            editItem={this.editItem.bind(this)}
          />
        </span>
        <span className={this.props.item.show}>
          <button
            className={this.props.item.completed}
            onClick={this.checkItem.bind(this, this.props.item.id)}
          />
          {this.props.item.text}
          <span id={this.props.item.completed}>
            <button
              onClick={this.deleteItem.bind(this, this.props.item.id)}
              className="bttn bttn-red"
              id="deleteBtn"
            >
              Delete Item
            </button>
          </span>
        </span>
      </li>
    );
  }
}
export default Todo;
