import React, { Component } from "react";
import Todo from "./todo";

class Todos extends Component {
  checkItem(id) {
    this.props.onCheck(id);
  }
  deleteItem(id) {
    this.props.onDelete(id);
  }
  editItem(id, text) {
    this.props.onEdit(id, text);
  }
  updateEdit(id) {
    this.props.onUpdateEdit(id);
  }
  render() {
    let listItems;
    if (this.props.items) {
      listItems = this.props.items.map(item => {
        return (
          <div key={item.id}>
            <ul>
              <Todo
                onDelete={this.deleteItem.bind(this)}
                onCheck={this.checkItem.bind(this)}
                editItem={this.editItem.bind(this)}
                updateEdit={this.updateEdit.bind(this)}
                item={item}
              />
            </ul>
          </div>
        );
      });
    }
    return <div>{listItems}</div>;
  }
}

export default Todos;
