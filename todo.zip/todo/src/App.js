import React, { Component } from "react";
import "./App.css";
import Todos from "./components/todos";
import AddTodo from "./components/addTodo";
import Footer from "./components/footer";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      filteredItems: [],
      filter: "all",
      count: 0
    };
  }
  handleAddItem(item) {
    let items = this.state.items;
    items.push(item);
    this.setState({ items: items, filteredItems: items });
    this.getCount();
  }
  handleCheckItem(id) {
    let items = this.state.items;
    let item = items.find(x => x.id === id);
    item.completed === "false"
      ? (item.completed = "true")
      : (item.completed = "false");
    this.setState({ items: items });
    this.filterItems();
    this.getCount();
  }
  handleDelete(id) {
    let items = this.state.items;
    let index = items.findIndex(x => x.id === id);
    items.splice(index, 1);
    this.setState({ items: items });
    this.filterItems();
    this.getCount();
  }
  handleEdit(id, text) {
    let items = this.state.items;
    let index = items.findIndex(x => x.id === id);
    items[index].text = text;
    this.setState({ items: items });
    this.filterItems();
    this.getCount();
  }
  handleUpdateEdit(id) {
    let items = this.state.items;
    let item = items.find(x => x.id === id);
    if (item.show === "show") {
      item.show = "hide";
      item.edit = "show";
    } else {
      item.edit = "hide";
      item.show = "show";
    }
    this.setState({ items: items });
    this.getCount();
  }
  handleFooterText() {
    let text;
    this.state.items.length === 0
      ? (text = "Add a new todo")
      : (text = "Double-click a Todo to edit");
    return text;
  }
  handleFilterItems(filter) {
    this.setState({ filter: filter }, () => {
      this.filterItems();
    });
  }
  filterItems() {
    let filteredItems = [];
    let item = {};
    if (this.state.filter === "all") {
      filteredItems = this.state.items;
      this.setState({ filteredItems: filteredItems });
    } else if (this.state.filter === "active") {
      const newItems = this.state.items.filter(x => x.completed === "false");
      this.setState({ filteredItems: newItems });
    } else {
      const doneItems = this.state.items.filter(x => x.completed === "true");
      filteredItems.push(item);
      this.setState({ filteredItems: doneItems });
    }
  }
  handleSelectAll() {
    let items = this.state.items;
    let flag = false;
    for (let item of items) {
      if (item.completed === "false") {
        flag = true;
      }
      item.completed = "true";
    }
    if (flag === false) {
      this.deselectAll();
    }
    this.setState({ items: items });
    this.filterItems();
    this.getCount();
  }
  deselectAll() {
    let items = this.state.items;
    items.map(x => {
      x.completed === "true"
        ? (x.completed = "false")
        : (x.completed = "false");
    });
    this.setState({ items: items });
    this.filterItems();
    this.getCount();
  }
  getCount() {
    let items = this.state.items.filter(x => x.completed === "false");
    if (items) {
      let count = items.length;
      return count;
    }
  }
  render() {
    return (
      <div className="wrap">
        <div className="wrap-center">
          <AddTodo
            selectAll={this.handleSelectAll.bind(this)}
            addTodo={this.handleAddItem.bind(this)}
            total={this.state.items.length}
          />
          <div id="todos">
            <Todos
              onDelete={this.handleDelete.bind(this)}
              onCheck={this.handleCheckItem.bind(this)}
              onEdit={this.handleEdit.bind(this)}
              onUpdateEdit={this.handleUpdateEdit.bind(this)}
              items={this.state.filteredItems}
            />
          </div>
        </div>
        <Footer
          filterItems={this.handleFilterItems.bind(this)}
          getFooterText={this.handleFooterText.bind(this)}
          count={this.getCount()}
        />
      </div>
    );
  }
}

export default App;
