import React, { Component } from "react";
import uuid from "uuid";

class addTodo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newItem: {}
    };
  }
  handleSubmit = e => {
    this.refs.title.value === ""
      ? alert("List can't be blank")
      : this.setState(
          {
            newItem: {
              id: uuid.v4(),
              text: this.refs.title.value,
              completed: "false",
              edit: "hide",
              show: "show"
            }
          },
          () => {
            this.props.addTodo(this.state.newItem);
            this.refs.title.value = "";
          }
        );
    e.preventDefault();
  };
  selectAll() {
    this.props.selectAll();
  }
  render() {
    return (
      <div id="addTodo">
        <h1>Add TODO</h1>
        <form onSubmit={this.handleSubmit.bind(this)}>
          <div>
            <input
              onClick={this.selectAll.bind(this)}
              type="button"
              className="bttn bttn-blue"
              value="Select all"
            />
            <label htmlFor="">New Item</label>
            <input className="inputs" type="text" ref="title" />
          </div>
        </form>
      </div>
    );
  }
}

export default addTodo;
